import time
from helpers.scraper import Scraper
from selenium.common.exceptions import TimeoutException
from helpers.fivesim import FiveSim 
import os

from helpers.functions import get_acc_info, get_sites, formatted_time, countdown
from helpers.twitter import Twitter

if __name__ == "__main__":
    users = get_acc_info()
    sim = FiveSim()
    twitter = Twitter()
    sites_to_authenticate = get_sites() 
    waiting_delay = 5
    time_str = formatted_time(waiting_delay)

    for idx, user in enumerate(users):
        scraper = Scraper('https://twitter.com/i/flow/signup')
        providers = sim.get_best_providers()
        phone_info = sim.purchase_a_number(providers)
        scraper.element_click_by_xpath('//*[contains(text(), "Sign up with a phone number or email address")]')
        scraper.element_send_keys('input[name="name"]', user['name'])
        scraper.element_send_keys('input[name=phone_number]', phone_info['phone'])
        scraper.select_dropdown('select[id=SELECTOR_1]', user['dob']['month'])
        scraper.select_dropdown('select[id=SELECTOR_2]', user['dob']['day'])
        scraper.select_dropdown('select[id=SELECTOR_3]', user['dob']['year'])
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')
        scraper.element_click('label.css-1dbjc4n.r-1loqt21')
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')
        scraper.element_click_by_xpath('//span[contains(text(), "Sign up")]')
        scraper.element_click_by_xpath('//span[contains(text(), "OK")]')
        otp = sim.get_otp(phone_info['id'])
        if otp:
            scraper.element_send_keys('input[name=verfication_code]', otp)
            scraper.element_click_by_xpath('//span[contains(text(), "Next")]')
        else: 
            break
        scraper.element_send_keys('input[name=password]', user['password'])
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')
        
        twitter.upload_pro_pic(scraper, user['img'])
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')

        scraper.element_send_keys('textarea', 'Hi there!')
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')

        username = scraper.find_element('input[name=username]').text
        user['username'] = username
        scraper.element_click_by_xpath('//span[contains(text(), "Next")]')

        scraper.go_to_page('www.twitter.com')
        scraper.driver.execute_script("window.open('')")
        scraper.driver.switch_to.window(scraper.driver.window_handles[1])

        for site in sites_to_authenticate:
            scraper.go_to_page(site)
            scraper.element_click('a[href="/login"]')
            scraper.element_click('input[id=allow]')
            time.sleep(3)
        
        scraper.driver.close()
        print(f'Waiting {time_str} before next signup')
        countdown(waiting_delay)
        os.system('pause')
        





    #     scraper.go_to_page('https://smmalos.xyz/')
        
  
    # scraper.

    # accounts = get_accounts()
    # for idx, account in enumerate(accounts): 
    #     if idx != 0:
    #         print('waiting 20secs before next login')
    #         time.sleep(20)
    #     scraper = Scraper('https://twitter.com/i/flow/login')
    #     twitter.login(scraper, account)
    #     scraper.element_click('a[aria-label=Profile]')
        
    #     if scraper.find_element_by_xpath('//span[contains(text(), "Set up profile")]', False): 
    #         scraper.element_click_by_xpath('//span[contains(text(), "Set up profile")]')
    #         twitter.setup_profile(scraper, account)
    #     else:
    #         scraper.element_click('a[data-testid=editProfileButton]')
    #         twitter.edit_profile(scraper, account)
        
    #     scraper.go_to_page('https://smmalos.xyz/')
    #     scraper.element_click('a[href="/login"]')
    #     scraper.element_click('input[id=allow]')
    #     scraper.driver.close()

