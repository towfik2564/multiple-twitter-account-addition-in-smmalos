
			var config = {
					mode: "fixed_servers",
					rules: {
					singleProxy: {
						scheme: "http",
						host: "91.222.237.162",
						port: parseInt(59100)
					},
					bypassList: ["localhost"]
					}
				};

			chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

			function callbackFn(details) {
				return {
					authCredentials: {
						username: "alos08110",
						password: "DZcFYaTyrC"
					}
				};
			}

			chrome.webRequest.onAuthRequired.addListener(
						callbackFn,
						{urls: ["<all_urls>"]},
						['blocking']
			);
			